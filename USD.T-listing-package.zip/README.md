# TetherUSD (USD.T) — Token Listing Package

This package contains everything you need to get USD.T listed with
logo and metadata across wallets and explorers.

- Contract: `TVBEPjNqw5pxmUTRVs94doA6ZSsBmbEeGS`
- Network: mainnet
- Explorer: https://tronscan.org/#/token20/TVBEPjNqw5pxmUTRVs94doA6ZSsBmbEeGS

## Files

- `info.json` — TrustWallet asset metadata (TRC20 format).
- `logo.png` is missing because no logo URL was set or it could not be fetched. Add a 256x256 PNG named `logo.png` before submitting.
- `tronscan-token-info.txt` — the exact values to paste into the Tronscan
  "Update Token Info" form.

## 1. TrustWallet assets (used by Trust Wallet and many others)

1. Fork https://github.com/trustwallet/assets
2. Create the folder: `blockchains/tron/assets/TVBEPjNqw5pxmUTRVs94doA6ZSsBmbEeGS/`
3. Add `info.json` and `logo.png` from this package into that folder.
4. Open a pull request. Requirements: logo must be a 256x256 PNG under 100kB,
   and the token should have meaningful on-chain activity.

## 2. Tronscan token information

1. Open https://tronscan.org/#/token20/TVBEPjNqw5pxmUTRVs94doA6ZSsBmbEeGS
2. Connect the contract owner wallet and choose "Update Token Info".
3. Fill in the fields using `tronscan-token-info.txt`, upload `logo.png`,
   and submit. Tronscan reviews the request before it goes live.

## 3. Verify your source first

Listings look far more trustworthy when the contract source is verified. Use the
"Verify on Tronscan" action in the app before submitting these listings.
