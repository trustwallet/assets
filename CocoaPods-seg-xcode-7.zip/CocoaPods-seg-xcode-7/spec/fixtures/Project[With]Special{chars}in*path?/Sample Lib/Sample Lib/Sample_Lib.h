//
//  Sample_Lib.h
//  Sample Lib
//
//  Created by Eloy Durán on 11/2/12.
//  Copyright (c) 2012 CocoaPods. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Sample_Lib : NSObject

@end
