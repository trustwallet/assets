require File.expand_path('../../../spec_helper', __FILE__)

module Pod
  describe Generator::XCConfig do
  end
end
