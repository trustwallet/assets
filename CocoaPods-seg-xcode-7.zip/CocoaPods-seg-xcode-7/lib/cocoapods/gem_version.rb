module Pod
  # The version of the cocoapods command line tool.
  #
  VERSION = '0.39.0' unless defined? Pod::VERSION
end
