# go-primitives
___
go-primitives is Go library that contains blockchain types and functions to work with them.  
It also supposed to contain extension functions for basic Go types.  
